"""AgentMeter (browser data-preparation bundle: scripts/build_web_prep.py)."""
